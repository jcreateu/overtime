package kr.go.overtime.reminder

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("overtime", MODE_PRIVATE) }
    private lateinit var startLabel: TextView
    private lateinit var nextLabel: TextView
    private lateinit var totalLabel: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createChannel()
        normalizeWorkday()
        render()
    }

    private fun normalizeWorkday() {
        val now = System.currentTimeMillis()
        val cal = java.util.Calendar.getInstance().apply { timeInMillis = now }
        if (cal.get(java.util.Calendar.HOUR_OF_DAY) < 3) cal.add(java.util.Calendar.DATE, -1)
        cal.set(java.util.Calendar.HOUR_OF_DAY, 3)
        cal.set(java.util.Calendar.MINUTE, 0)
        cal.set(java.util.Calendar.SECOND, 0)
        cal.set(java.util.Calendar.MILLISECOND, 0)
        val workdayKey = SimpleDateFormat("yyyyMMdd", Locale.KOREA).format(cal.time)
        val savedKey = prefs.getString("workdayKey", null)
        if (savedKey != workdayKey || !prefs.contains("startTime")) {
            prefs.edit().putString("workdayKey", workdayKey).putLong("startTime", now)
                .putLong("nextAlert", now + 50 * 60 * 1000L).apply()
        }
    }

    private fun render() {
        val pad = (18 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(pad, pad, pad, pad)
        }
        root.addView(TextView(this).apply {
            text = "초과근무 알림"
            textSize = 24f
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
        startLabel = TextView(this).apply { textSize = 17f }
        nextLabel = TextView(this).apply { textSize = 17f }
        totalLabel = TextView(this).apply { textSize = 17f }
        root.addView(startLabel); root.addView(nextLabel); root.addView(totalLabel)

        val delayInput = EditText(this).apply {
            hint = "첫 알림까지 시간(분), 기본 50"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setText("50")
        }
        root.addView(delayInput, LinearLayout.LayoutParams(-1, -2))

        root.addView(Button(this).apply {
            text = "첫 알림 시간 설정"
            setOnClickListener {
                val minutes = delayInput.text.toString().toLongOrNull()?.coerceIn(1, 720) ?: 50L
                prefs.edit().putLong("nextAlert", System.currentTimeMillis() + minutes * 60_000L).apply()
                scheduleNext()
                render()
            }
        })
        root.addView(Button(this).apply {
            text = "초과근무 시작 시각 수정"
            setOnClickListener { editStartTime() }
        })
        root.addView(Button(this).apply {
            text = if (Settings.canDrawOverlays(this@MainActivity)) "작은 타이머 창 켜기" else "타이머 창 권한 설정"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else {
                    startForegroundService(Intent(this@MainActivity, OverlayService::class.java))
                    Toast.makeText(this@MainActivity, "작은 타이머 창을 실행했습니다.", Toast.LENGTH_SHORT).show()
                }
            }
        })
        root.addView(Button(this).apply {
            text = "알림 예약"
            setOnClickListener { scheduleNext(); Toast.makeText(this@MainActivity, "알림을 예약했습니다.", Toast.LENGTH_SHORT).show() }
        })
        root.addView(Button(this).apply {
            text = "타이머 창 종료"
            setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) }
        })
        setContentView(root)
        updateLabels()
    }

    private fun updateLabels() {
        val now = System.currentTimeMillis()
        val start = prefs.getLong("startTime", now)
        val next = prefs.getLong("nextAlert", now + 50 * 60_000L)
        val fmt = SimpleDateFormat("HH:mm", Locale.KOREA)
        startLabel.text = "시작 시각: ${fmt.format(Date(start))}"
        nextLabel.text = "다음 알림: ${fmt.format(Date(next))}"
        val elapsed = ((now - start).coerceAtLeast(0) / 60_000L)
        totalLabel.text = "총 초과근무: %02d시간 %02d분".format(elapsed / 60, elapsed % 60)
    }

    private fun editStartTime() {
        val input = EditText(this).apply {
            hint = "HH:mm (예: 18:30)"
            setText(SimpleDateFormat("HH:mm", Locale.KOREA).format(Date(prefs.getLong("startTime", System.currentTimeMillis()))))
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("초과근무 시작 시각")
            .setView(input)
            .setPositiveButton("저장") { _, _ ->
                try {
                    val parts = input.text.toString().trim().split(":")
                    val cal = java.util.Calendar.getInstance()
                    cal.set(java.util.Calendar.HOUR_OF_DAY, parts[0].toInt())
                    cal.set(java.util.Calendar.MINUTE, parts[1].toInt())
                    cal.set(java.util.Calendar.SECOND, 0)
                    cal.set(java.util.Calendar.MILLISECOND, 0)
                    prefs.edit().putLong("startTime", cal.timeInMillis).apply()
                    render()
                } catch (_: Exception) {
                    Toast.makeText(this, "HH:mm 형식으로 입력해 주세요.", Toast.LENGTH_SHORT).show()
                }
            }.setNegativeButton("취소", null).show()
    }

    private fun scheduleNext() {
        val alarm = getSystemService(ALARM_SERVICE) as AlarmManager
        val intent = Intent(this, ReminderReceiver::class.java)
        val pi = PendingIntent.getBroadcast(this, 1001, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val trigger = prefs.getLong("nextAlert", System.currentTimeMillis() + 50 * 60_000L)
        try {
            if (Build.VERSION.SDK_INT >= 31 && !alarm.canScheduleExactAlarms()) {
                Toast.makeText(this, "정확한 알림 권한을 설정하면 알림 정확도가 높아집니다.", Toast.LENGTH_LONG).show()
            } else {
                alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi)
            }
        } catch (_: SecurityException) {
            alarm.set(AlarmManager.RTC_WAKEUP, trigger, pi)
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("overtime", "초과근무 알림", NotificationManager.IMPORTANCE_HIGH))
        }
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 20)
        }
    }
}

package kr.go.overtime.reminder

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class OverlayService : Service() {
    private var windowManager: WindowManager? = null
    private var view: TextView? = null
    private var params: WindowManager.LayoutParams? = null
    private var downX = 0f
    private var downY = 0f
    private var initialX = 0
    private var initialY = 0

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("overlay", "타이머 창 실행", NotificationManager.IMPORTANCE_LOW))
        }
        val notification = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "overlay") else @Suppress("DEPRECATION") Notification.Builder(this)
        startForeground(3001, notification.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("초과근무 타이머 실행 중").setContentText("화면 위에 타이머를 표시합니다.").build())
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        view = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 12f
            setPadding(18, 8, 18, 8)
            setBackgroundColor(Color.rgb(45, 55, 65))
            setOnTouchListener { _, event ->
                val p = params ?: return@setOnTouchListener false
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = event.rawX; downY = event.rawY; initialX = p.x; initialY = p.y; true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        p.x = initialX + (event.rawX - downX).toInt()
                        p.y = initialY + (event.rawY - downY).toInt()
                        windowManager?.updateViewLayout(view, p); true
                    }
                    else -> false
                }
            }
        }
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 24; y = 120 }
        windowManager?.addView(view, params)
        update()
    }

    private fun update() {
        val prefs = getSharedPreferences("overtime", MODE_PRIVATE)
        val start = prefs.getLong("startTime", System.currentTimeMillis())
        val next = prefs.getLong("nextAlert", System.currentTimeMillis() + 50 * 60_000L)
        val now = System.currentTimeMillis()
        val mins = (now - start).coerceAtLeast(0) / 60_000L
        val remain = ((next - now).coerceAtLeast(0) / 1000L)
        val fmt = SimpleDateFormat("HH:mm", Locale.KOREA)
        view?.text = "다음 알림까지 %02d:%02d  |  예정 시각 %s  |  총 초과근무 %02d:%02d".format(
            remain / 60, remain % 60, fmt.format(Date(next)), mins / 60, mins % 60)
        view?.postDelayed({ update() }, 1000)
    }

    override fun onDestroy() {
        try { if (view != null) windowManager?.removeView(view) } catch (_: Exception) {}
        view = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
